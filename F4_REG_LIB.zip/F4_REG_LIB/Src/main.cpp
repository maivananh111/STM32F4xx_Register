


#include <stdint.h>
#include "stm32f4xx.h"
#include "Config.h"
#include "string.h"

const char *TAG = "STM32_LOG";
// CS = PA8
uint8_t FlsRxbuf[256];
uint8_t FlsTxbuf[256];
uint32_t FlsAddr = 0x5100UL;

void ShowFlashData(uint32_t addr);


int main (void){
	Periph_Initialize();


	while(1){
		GPIO_Reset(GPIOC, 13);

		if(LoRa_ReqTimer_Flag == true){
			LoRa_SendCommand(CMD_DATA, DATA_NODATA);
			STM_LOG(BOLD_CYAN, TAG, "Getway request command: %s, data: %s. Tick = %lu", CMD_DATA, DATA_NODATA, gettick());

			LoRa_ReqTimer_Flag = false;
		}

		if(RxFromEsp_Flag == true){
			Packet_t RxPacket = ParseData((char *)uart_Rxbuf);
			if(RxPacket.command != Command_Error){
				STM_LOG(BOLD_RED, TAG, "STM32 receive command: %s(%d), data: %s. Tick = %lu", RxPacket.cmd, RxPacket.command, RxPacket.data, gettick());
				delay_ms(1);
				switch(RxPacket.command){
					case Command_ID:
					break;
					case Command_Data:
					break;
					case Command_Control:
						LoRaTransmit(RxPacket.packet);

					break;
					case Command_Wifi:
						if(strcmp(RxPacket.data, DATA_ON) == 0) ESP32_WiFi_On((char *)"Redmi Note 9S", (char *)"khoavantue");
						if(strcmp(RxPacket.data, DATA_OFF) == 0) ESP32_WiFi_Off();
					default:
					break;
				}
			}
			RxFromEsp_Flag = false;
		}

		if(LoRa_Resp_Flag == true){
			if(LoRa_Resp_Packet.command != Command_Error){
				STM_LOG(BOLD_YELLOW, TAG, "Node response command: %s(%d), data: %s. Tick = %lu", LoRa_Resp_Packet.cmd, (int)LoRa_Resp_Packet.command, LoRa_Resp_Packet.data, gettick());
				delay_ms(2);
				switch(LoRa_Resp_Packet.command){
					case Command_ID:
					break;
					case Command_Data:
						if(strcmp(LoRa_Resp_Packet.data, "OK") != 0)
							ESP32_SendEnvData(LoRa_Resp_Packet.data);

					break;
					case Command_Control:
					break;
					default:
					break;
				}

			}
			LoRa_Resp_Flag = false;
		}


	}
}

void ShowFlashData(uint32_t addr){
	STM_LOG(BOLD_PURPLE, TAG, "Read from ID: 0x%08x.", addr);
	spiflash.ReadBytes(FlsAddr, FlsRxbuf, 256);
	for(uint8_t i=0; i<16; i++){
		STM_LOG(BOLD_WHITE, TAG, "0x%08x: 0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x|0x%02x", addr + i*16,
				FlsRxbuf[0+i*16], FlsRxbuf[1+i*16], FlsRxbuf[2+i*16],  FlsRxbuf[3+i*16],  FlsRxbuf[4+i*16],  FlsRxbuf[5+i*16],  FlsRxbuf[6+i*16],  FlsRxbuf[7+i*16],
				FlsRxbuf[8+i*16], FlsRxbuf[9+i*16], FlsRxbuf[10+i*16], FlsRxbuf[11+i*16], FlsRxbuf[12+i*16], FlsRxbuf[13+i*16], FlsRxbuf[14+i*16], FlsRxbuf[15+i*16]);
	}
}




















