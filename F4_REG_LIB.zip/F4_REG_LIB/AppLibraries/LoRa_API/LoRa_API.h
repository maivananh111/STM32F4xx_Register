/*
 * LoRa_API.h
 *
 *  Created on: Dec 14, 2022
 *      Author: anh
 */

#ifndef LORA_API_H_
#define LORA_API_H_


#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "LORA.h"
#include "TIM_F4xx.h"
#include "Getway_API.h"


#define LORA_NUM_NODE           2



extern char *lora_RxBuf;
extern bool LoRa_Resp_Flag;
extern Packet_t LoRa_Resp_Packet;


void LoRa_AP_Init(LoRa *lora, TIM *timer);
void LoRa_API_TimerHandler(void *Parameter, TIM_Event_t event);
void LoRa_Receive_IRQHandler(void *arg, uint8_t len);


void LoRa_SendCommand(const char *command, const char *fomat, ...);
void LoRaTransmit(const char *fomat, ...);

int FindChar(char *str, char ch);
char *GetCmd(char *str);
char *GetData(char *str);

Packet_t ParseData(char *data);

void LoRa_RequestData(void);


#endif /* LORA_API_H_ */
