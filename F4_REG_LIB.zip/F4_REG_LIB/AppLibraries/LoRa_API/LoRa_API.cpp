/*
 * LoRa_API.cpp
 *
 *  Created on: Dec 14, 2022
 *      Author: anh
 */
#include "LoRa_API.h"
#include "TIM_F4xx.h"
#include "STM_LOG.h"
#include "ESP32_API.h"

static LoRa *_lora;
static TIM  *_tim;

//static const char * TAG = "STM32_LOG";


char *lora_RxBuf;
bool LoRa_Resp_Flag = false;
Packet_t LoRa_Resp_Packet;

bool All_response = false;
bool Response_State[LORA_NUM_NODE] = {false};


void LoRa_AP_Init(LoRa *lora, TIM *timer){
	_lora = lora;
	_tim = timer;
}



void LoRa_SendCommand(const char *command, const char *fomat, ...){
	char *Temp_buffer = NULL;
	va_list args;
	va_start(args, fomat);

	uint16_t length = vsnprintf(Temp_buffer, 0, fomat, args);
	Temp_buffer = (char *)malloc(length * sizeof(char));
	vsprintf(Temp_buffer, fomat, args);
	va_end(args);

	char *Out_buffer = (char *)malloc((strlen(command) + 2 + length)*sizeof(char));
	sprintf(Out_buffer, "%s: %s", command, Temp_buffer);

	_lora -> beginPacket();
	_lora -> write((uint8_t*)Out_buffer, (size_t)strlen(Out_buffer) );
	_lora -> endPacket();
	_lora -> Receive(0);

	free(Out_buffer);
	free(Temp_buffer);
}

void LoRaTransmit(const char *fomat, ...){
	char *Temp_buffer = NULL;
	va_list args;
	va_start(args, fomat);

	uint16_t length = vsnprintf(Temp_buffer, 0, fomat, args);
	Temp_buffer = (char *)malloc(length * sizeof(char));
	vsprintf(Temp_buffer, fomat, args);
	va_end(args);

	_lora -> beginPacket();
	_lora -> write((uint8_t*)Temp_buffer, (size_t)strlen(Temp_buffer) );
	_lora -> endPacket();
	_lora -> Receive(0);

	free(Temp_buffer);
}

void LoRa_RequestData(void){
	LoRaTransmit(CMD_DATA, DATA_NODATA);
	All_response = false;
	_tim -> ResetCounter();

}

void LoRa_Receive_IRQHandler(void *arg, uint8_t len){
	LoRa *lr = (LoRa *)arg;
	uint8_t packetSize = len;
	if(packetSize){
		lora_RxBuf = (char *)malloc(packetSize+1);
		for (int i = 0; i < packetSize; i++) lora_RxBuf[i] = lr -> read();
		lora_RxBuf[packetSize] = '\0';

		LoRa_Resp_Packet = ParseData(lora_RxBuf);
		LoRa_Resp_Flag = true;

		free(lora_RxBuf);
	}
}

void LoRa_API_TimerHandler(void *Parameter, TIM_Event_t event){
	switch(event){
		case TIM_Update_Event:

		break;
		default:
		break;
	}
}




