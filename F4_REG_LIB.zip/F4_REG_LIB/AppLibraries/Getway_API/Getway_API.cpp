/*
 * Getway_API.cpp
 *
 *  Created on: Dec 15, 2022
 *      Author: anh
 */

#include "Getway_API.h"
#include "stdlib.h"
#include "string.h"



int FindChar(char *str, char ch){
	char *chptr = strchr(str, ch);
	if(chptr == NULL) return -1;
	return (int)(chptr - str);
}

char *GetCmd(char *str){
	int index = FindChar(str, ':');
    if(index > 0){
    	char *cmd = (char *)malloc(index + 1);
    	strncpy(cmd, str, index);
    	cmd[index] = '\0';
    	return cmd;
    }
    return NULL;
}

char *GetData(char *str){
	int index = FindChar(str, ':') + 2; //= 5
    if(index > 0){
    	uint8_t datalen = strlen(str) - index;
    	char *tmp = (char *)malloc(datalen + 1);
    	for(uint8_t i = index; i<strlen(str); i++) tmp[i - index] = str[i];
    	tmp[datalen] = '\0';
    	return tmp;
    }
    return NULL;
}



Packet_t ParseData(char *data){
	Packet_t packet;
	packet.packet = data;
	packet.cmd = GetCmd(data);
	packet.data = GetData(data);
	if(packet.cmd == NULL || packet.data == NULL) {
		packet.command = Command_Error;
		goto ret;
	}


	if     (strcmp(packet.cmd, CMD_ID) == 0)   	   packet.command = Command_ID;
	else if(strcmp(packet.cmd, CMD_DATA) == 0) 	   packet.command = Command_Data;
	else if(strcmp(packet.cmd, CMD_CONTROL) == 0)  packet.command = Command_Control;
	else if(strcmp(packet.cmd, CMD_WIFI) == 0)     packet.command = Command_Wifi;
	else if(strcmp(packet.cmd, CMD_ETH) == 0) 	   packet.command = Command_Eth;
	else 										   packet.command = Command_Unknow;

	ret:
	return packet;
}






