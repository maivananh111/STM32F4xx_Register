/*
 * Getway_API.h
 *
 *  Created on: Dec 15, 2022
 *      Author: anh
 */

#ifndef GETWAY_API_H_
#define GETWAY_API_H_

#include "stdio.h"



#define CMD_ID             "ID"
#define CMD_DATA           "DATA"
#define CMD_CONTROL 	   "CONTROL"
#define CMD_WIFI           "WIFI"
#define CMD_ETH            "ETH"

#define DATA_NODATA 	   "*"
#define DATA_ON            "ON"
#define DATA_OFF           "OFF"

#define CMD_1ON            "1on"
#define CMD_2ON            "2on"
#define CMD_3ON            "3on"
#define CMD_1OFF           "1off"
#define CMD_2OFF           "2off"
#define CMD_3OFF           "3off"


typedef enum{
	Command_ID,
	Command_Data,
	Command_Control,
	Command_Wifi,
	Command_Eth,
	Command_Error,
	Command_Unknow,
} PackCommand_t;


typedef struct{
	char *packet = NULL;
	char *cmd = NULL;
	char *data = NULL;
	PackCommand_t command = Command_Data;
} Packet_t;


int FindChar(char *str, char ch);
char *GetCmd(char *str);
char *GetData(char *str);
Packet_t ParseData(char *data);

#endif /* GETWAY_API_H_ */
