
#if 0

#ifdef __cplusplus
extern "C"{
#endif

#include "lvgl.h"
#include "lv_conf.h"

void LCD_flush(lv_disp_drv_t *Disp_Driver, const lv_area_t *Disp_Area,  lv_color_t * Color_Buffer);

#ifdef __cplusplus
}
#endif

#endif
